import React from 'react';
import { Edit, Plus } from 'lucide-react';
import PatientHeader from './patient/PatientHeader';
import PatientTabs from './patient/PatientTabs';
import PatientOdontogram from './patient/PatientOdontogram';
import TreatmentList from './patient/TreatmentList';

const PatientView = () => {
  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      <PatientHeader />
      <PatientTabs />
      
      <div className="mt-6 grid grid-cols-12 gap-6">
        <div className="col-span-5">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold mb-4">Odontogram</h3>
            <PatientOdontogram />
          </div>
        </div>
        
        <div className="col-span-7">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Treatment Plan</h3>
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                <Plus className="w-4 h-4" />
                Add Treatment
              </button>
            </div>
            <TreatmentList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientView;