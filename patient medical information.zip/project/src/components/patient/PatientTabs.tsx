import React from 'react';

const tabs = [
  "Patient Information",
  "Appointment History",
  "Next Treatment",
  "Medical Record"
];

const PatientTabs = () => {
  return (
    <div className="border-b border-gray-200">
      <nav className="flex gap-8">
        {tabs.map((tab, index) => (
          <button
            key={tab}
            className={`py-4 px-1 text-sm font-medium border-b-2 -mb-px ${
              index === 0
                ? 'border-blue-500 text-blue-500'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default PatientTabs;