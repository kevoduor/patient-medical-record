import React from 'react';
import { Check, Clock } from 'lucide-react';

const treatments = [
  {
    id: 1,
    tooth: '03',
    condition: 'Advanced Decay',
    treatment: 'Root Canal',
    dentist: 'Dr. Snap MacIntosh',
    status: 'done',
  },
  {
    id: 2,
    tooth: '12',
    condition: 'Decay in pulp',
    treatment: 'Deep Filling',
    dentist: 'Dr. Snap MacIntosh',
    status: 'pending',
  },
];

const TreatmentList = () => {
  return (
    <div className="space-y-4">
      {treatments.map((treatment) => (
        <div
          key={treatment.id}
          className="p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-1 bg-gray-100 rounded text-sm font-medium">
                  #{treatment.tooth}
                </span>
                <span className="text-sm text-gray-500">
                  {treatment.condition}
                </span>
              </div>
              <p className="font-medium">{treatment.treatment}</p>
              <p className="text-sm text-gray-500 mt-1">{treatment.dentist}</p>
            </div>
            <div className="flex items-center gap-1 text-sm">
              {treatment.status === 'done' ? (
                <Check className="w-4 h-4 text-green-500" />
              ) : (
                <Clock className="w-4 h-4 text-orange-500" />
              )}
              <span className={treatment.status === 'done' ? 'text-green-500' : 'text-orange-500'}>
                {treatment.status === 'done' ? 'Done' : 'Pending'}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TreatmentList;