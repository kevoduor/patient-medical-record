import React from 'react';
import { Edit } from 'lucide-react';

const PatientHeader = () => {
  return (
    <div className="flex items-start justify-between mb-6">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gray-200 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&q=80" 
            alt="Willie Jennie"
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold text-gray-900">Willie Jennie</h1>
            <button className="p-1 text-gray-400 hover:text-gray-600">
              <Edit className="w-4 h-4" />
            </button>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Male • 32 years • ID: #PAT-20240312-001
          </p>
        </div>
      </div>
      
      <button className="px-4 py-2 text-blue-500 font-medium rounded-lg hover:bg-blue-50">
        Create Appointment
      </button>
    </div>
  );
}

export default PatientHeader;