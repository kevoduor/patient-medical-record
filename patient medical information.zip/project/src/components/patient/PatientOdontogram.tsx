import React, { useState } from 'react';
import ToothGrid from './odontogram/ToothGrid';

const PatientOdontogram = () => {
  const [selectedTooth, setSelectedTooth] = useState<string>();

  const handleToothSelect = (toothId: string) => {
    setSelectedTooth(toothId === selectedTooth ? undefined : toothId);
  };

  return (
    <div className="space-y-6">
      <ToothGrid
        selectedTooth={selectedTooth}
        onToothSelect={handleToothSelect}
      />
      
      {selectedTooth && (
        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Tooth #{selectedTooth}</h4>
          <div className="grid grid-cols-2 gap-2">
            <button className="px-3 py-2 text-sm text-gray-600 bg-white rounded border border-gray-200 hover:bg-gray-50">
              Add Condition
            </button>
            <button className="px-3 py-2 text-sm text-gray-600 bg-white rounded border border-gray-200 hover:bg-gray-50">
              Add Treatment
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientOdontogram;