import React from 'react';
import ToothShape from './ToothShape';

interface ToothGridProps {
  selectedTooth?: string;
  onToothSelect?: (toothId: string) => void;
}

const ToothGrid: React.FC<ToothGridProps> = ({ selectedTooth, onToothSelect }) => {
  // Universal Numbering System (American)
  const upperTeeth = Array.from({ length: 16 }, (_, i) => ({
    id: String(i + 1).padStart(2, '0'),
    conditions: i === 2 ? ['decay'] : [] // Example condition for tooth #3
  }));
  
  const lowerTeeth = Array.from({ length: 16 }, (_, i) => ({
    id: String(32 - i).padStart(2, '0'),
    conditions: i === 11 ? ['decay'] : [] // Example condition for tooth #21
  }));

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Upper Teeth Numbers */}
      <div className="grid grid-cols-16 gap-1 mb-1">
        {upperTeeth.map(tooth => (
          <div key={`upper-num-${tooth.id}`} className="text-center text-xs font-medium text-gray-500">
            {tooth.id}
          </div>
        ))}
      </div>
      
      {/* Upper Teeth */}
      <div className="grid grid-cols-16 gap-1 mb-8">
        {upperTeeth.map(tooth => (
          <div key={`upper-${tooth.id}`} className="flex justify-center">
            <ToothShape
              selected={selectedTooth === tooth.id}
              onClick={() => onToothSelect?.(tooth.id)}
              conditions={tooth.conditions}
            />
          </div>
        ))}
      </div>
      
      {/* Lower Teeth */}
      <div className="grid grid-cols-16 gap-1 mb-1">
        {lowerTeeth.map(tooth => (
          <div key={`lower-${tooth.id}`} className="flex justify-center">
            <ToothShape
              selected={selectedTooth === tooth.id}
              onClick={() => onToothSelect?.(tooth.id)}
              conditions={tooth.conditions}
            />
          </div>
        ))}
      </div>
      
      {/* Lower Teeth Numbers */}
      <div className="grid grid-cols-16 gap-1">
        {lowerTeeth.map(tooth => (
          <div key={`lower-num-${tooth.id}`} className="text-center text-xs font-medium text-gray-500">
            {tooth.id}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToothGrid;