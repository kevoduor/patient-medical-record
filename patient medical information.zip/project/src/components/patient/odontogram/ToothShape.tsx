import React from 'react';

interface ToothShapeProps {
  selected?: boolean;
  onClick?: () => void;
  conditions?: string[];
}

const ToothShape: React.FC<ToothShapeProps> = ({ selected, onClick, conditions = [] }) => {
  return (
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      onClick={onClick}
      className={`cursor-pointer transition-colors ${selected ? 'text-blue-500' : 'text-gray-400'}`}
    >
      {/* Crown */}
      <path
        d="M8 12C8 8 12 4 20 4C28 4 32 8 32 12C32 16 28 28 20 28C12 28 8 16 8 12Z"
        stroke="currentColor"
        strokeWidth="2"
        fill={conditions.includes('decay') ? '#FEE2E2' : 'white'}
      />
      
      {/* Root Left */}
      <path
        d="M14 28L12 36"
        stroke="currentColor"
        strokeWidth="2"
        fill="none"
      />
      
      {/* Root Center */}
      <path
        d="M20 28L20 36"
        stroke="currentColor"
        strokeWidth="2"
        fill="none"
      />
      
      {/* Root Right */}
      <path
        d="M26 28L28 36"
        stroke="currentColor"
        strokeWidth="2"
        fill="none"
      />
      
      {/* Surface Markers */}
      <path
        d="M20 8L20 24"
        stroke="currentColor"
        strokeWidth="1"
        strokeDasharray="2 2"
      />
      <path
        d="M12 16L28 16"
        stroke="currentColor"
        strokeWidth="1"
        strokeDasharray="2 2"
      />
    </svg>
  );
};

export default ToothShape;