export type AppointmentStatus = 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
export type AppointmentType = 'general-checkup' | 'scaling' | 'bleaching' | 'deep-treatment' | 'surgery';

export interface Appointment {
  id: number;
  patient: string;
  time: string;
  duration: string;
  type: AppointmentType;
  status: AppointmentStatus;
  color: string;
}

export const appointmentColors = {
  'general-checkup': {
    bg: 'rgb(254, 226, 226)',
    border: 'rgb(254, 202, 202)',
    text: 'rgb(185, 28, 28)'
  },
  'scaling': {
    bg: 'rgb(220, 252, 231)',
    border: 'rgb(187, 247, 208)',
    text: 'rgb(22, 163, 74)'
  },
  'bleaching': {
    bg: 'rgb(224, 242, 254)',
    border: 'rgb(186, 230, 253)',
    text: 'rgb(2, 132, 199)'
  },
  'deep-treatment': {
    bg: 'rgb(237, 233, 254)',
    border: 'rgb(221, 214, 254)',
    text: 'rgb(109, 40, 217)'
  },
  'surgery': {
    bg: 'rgb(255, 237, 213)',
    border: 'rgb(254, 215, 170)',
    text: 'rgb(234, 88, 12)'
  }
};